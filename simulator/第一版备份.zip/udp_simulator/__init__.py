"""UDP data simulator package."""

